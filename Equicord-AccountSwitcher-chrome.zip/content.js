if (typeof browser === "undefined") {
    var browser = chrome;
}

function injectRendererCss() {
    if (document.getElementById("equicord-renderer-css")) return;

    const link = document.createElement("link");
    link.id = "equicord-renderer-css";
    link.rel = "stylesheet";
    link.href = browser.runtime.getURL("dist/Equicord.css");

    (document.head || document.documentElement).append(link);
}

injectRendererCss();

document.addEventListener(
    "DOMContentLoaded",
    () => {
        injectRendererCss();
        window.postMessage({
            type: "vencord:meta",
            meta: {
                EXTENSION_VERSION: browser.runtime.getManifest().version,
                EXTENSION_BASE_URL: browser.runtime.getURL(""),
                RENDERER_CSS_URL: browser.runtime.getURL("dist/Equicord.css"),
            }
        });
    },
    { once: true }
);
